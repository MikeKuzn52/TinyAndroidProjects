package com.mikekuzn.example.singleactivitynavigation

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.NavController
import androidx.navigation.Navigation
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.google.android.material.bottomnavigation.BottomNavigationView

lateinit var MAIN: MainActivity

class MainActivity : AppCompatActivity() {

    lateinit var navController: NavController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MAIN = this
        setContentView(R.layout.activity_main)
        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.BottomNavigationView)
        navController = Navigation.findNavController(this, R.id.NavHostFragment)
        /*
        val appBarConfiguration = AppBarConfiguration(setOf(
            R.id.fragment1,
            R.id.fragment2,
            R.id.fragment3,
            R.id.fragment4
        ))
        setupActionBarWithNavController(navController, appBarConfiguration)
        //bottomNavigationView.setupWithNavController(navController)
        */
        //val navHostFragment =
        //    supportFragmentManager.findFragmentById(R.id.fragment) as NavHostFragment
        //val navController = navHostFragment.navController

        //binding.bottomNavigationView.setupWithNavController(navController)
        //binding.navigationBb.setupWithNavController(navController)
        //binding.mainNavBnv  .setupWithNavController(navController)

        /*
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //val navContoller = findNavController(R.id.fragment)
        //binding.bottomNavigationView.setupWithNavController(navContoller)


        */
    }
}