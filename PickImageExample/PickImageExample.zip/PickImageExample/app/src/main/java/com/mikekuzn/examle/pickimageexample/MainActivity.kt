package com.mikekuzn.examle.pickimageexample

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.mikekuzn.examle.pickimageexample.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    //private val getImageUrl = registerForActivityResult()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }
}
//    implementation 'android.appcompat:appcompat:1.5.1'